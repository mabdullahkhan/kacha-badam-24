<script lang="ts"></script>

<section class={$$props.class}>
  <!--  -->
</section>

<svg
  class={$$props.class}
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 24 24"
  width="24"
  height="24"
>
  <path
    d="M20 6H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h16c.55 0 1-.45 1-1V7c0-.55-.45-1-1-1zm0 11H4v-8h16v8zm-6-6H8v2h6v-2zm0-3H8v2h6V8z"
  />
</svg>

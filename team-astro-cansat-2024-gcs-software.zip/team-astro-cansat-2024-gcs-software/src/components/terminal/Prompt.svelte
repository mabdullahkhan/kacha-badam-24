<script lang="ts">
  import RocketIcon from '../icons/RocketIcon.svelte';
</script>

<span class="flex h-fit items-center gap-x-1 text-primary">
  <RocketIcon />
  <span>astro:~$</span>
</span>

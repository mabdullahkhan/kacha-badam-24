<h5 class="{$$props.class} h5">
  <slot />
</h5>

<h4 class="{$$props.class} h4 font-semibold text-secondary-500 underline">
  <slot />
</h4>

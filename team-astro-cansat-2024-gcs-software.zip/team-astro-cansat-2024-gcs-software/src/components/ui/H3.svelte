<h3 class="{$$props.class} h3 font-semibold">
  <slot />
</h3>

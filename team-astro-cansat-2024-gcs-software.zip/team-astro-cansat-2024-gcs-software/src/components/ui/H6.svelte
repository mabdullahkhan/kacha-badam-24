<h5 class="{$$props.class} h6 font-medium">
  <slot />
</h5>
